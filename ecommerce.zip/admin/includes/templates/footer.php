        <div class="footer">
            
        </div>

        <script src="<?php echo $js; ?>jquery-3.3.1.min.js"></script>       <!-- $js variable is declared in eCommerce\admin\init.php -->
        <script src="<?php echo $js; ?>jquery-ui.min.js"></script>          <!-- $js variable is declared in eCommerce\admin\init.php -->
        <script src="<?php echo $js; ?>bootstrap.min.js"></script>          <!-- $js variable is declared in eCommerce\admin\init.php -->
        <script src="<?php echo $js; ?>jquery.selectBoxIt.min.js"></script> <!-- $js variable is declared in eCommerce\admin\init.php -->
        <script src="<?php echo $js; ?>backend.js"></script>                <!-- $js variable is declared in eCommerce\admin\init.php -->
    </body>
</html>